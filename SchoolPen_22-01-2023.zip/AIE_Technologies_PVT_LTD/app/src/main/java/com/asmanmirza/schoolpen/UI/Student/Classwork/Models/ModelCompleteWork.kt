package com.asmanmirza.schoolpen.UI.Student.Classwork.Models

class ModelCompleteWork (var id:String, var title:String, var dueDate:String, var chTitle:String, var chDescription:String)