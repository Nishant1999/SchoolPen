package com.asmanmirza.schoolpen.UI.Student.Learn.Models

class ModelLearnButtons(var vector:Int, var title:String)