package com.asmanmirza.schoolpen.UI.Student.Learn.Models

class ModelLeaderBoard (var id:String, var name:String, var percent:String, var imageUrl:String)