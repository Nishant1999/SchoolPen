package com.asmanmirza.schoolpen.Models

class ModelNotice(var title:String, var date:String, var description:String, var file:String, var type:String)