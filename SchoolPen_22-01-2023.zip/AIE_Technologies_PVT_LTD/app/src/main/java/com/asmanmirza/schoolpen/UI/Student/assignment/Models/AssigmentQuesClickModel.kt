package com.asmanmirza.schoolpen.UI.Student.assignment.Models

data class AssigmentQuesClickModel(val title: String, val isSelected: Boolean)
