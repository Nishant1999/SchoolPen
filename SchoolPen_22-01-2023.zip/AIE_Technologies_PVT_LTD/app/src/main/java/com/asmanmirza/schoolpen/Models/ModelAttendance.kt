package com.asmanmirza.schoolpen.Models

class ModelAttendance(var id:String, var name:String, var imageUrl:String, var present:Boolean)