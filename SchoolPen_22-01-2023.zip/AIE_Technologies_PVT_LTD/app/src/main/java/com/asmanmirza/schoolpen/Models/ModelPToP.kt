package com.asmanmirza.schoolpen.Models

class ModelPToP(var id:String, var message:String, var image:String, var timeStamp:String)