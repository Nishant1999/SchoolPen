package com.asmanmirza.schoolpen.UI.Student.assignment.Models

data class AssignmentQuesAnsModel(val questionType: String, var isSelected: Boolean)
