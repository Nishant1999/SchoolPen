package com.asmanmirza.schoolpen.UI.Student.Classwork.Models

class ModelTeacherRemarks (var id:String, var name:String, var message:String, var subject:String, var timeStamp:String, var imageUrl:String)