package com.asmanmirza.schoolpen.UI.Student.Learn.Models

class ModelWKnowledge(var id:String)