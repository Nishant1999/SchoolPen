package com.asmanmirza.schoolpen.UI.Student.Learn.Models

class ModelDp(var id:String, var imageUrl:String, var selected:Boolean)