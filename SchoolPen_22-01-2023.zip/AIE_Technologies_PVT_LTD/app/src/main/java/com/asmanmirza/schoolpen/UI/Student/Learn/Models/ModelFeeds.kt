package com.asmanmirza.schoolpen.UI.Student.Learn.Models

class ModelFeeds (var id:String)