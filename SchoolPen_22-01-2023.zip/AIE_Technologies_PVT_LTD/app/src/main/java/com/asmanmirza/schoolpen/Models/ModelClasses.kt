package com.asmanmirza.schoolpen.Models

class ModelClasses (var id:String, var period:String, var stream:String, var teacherName:String, var chapter:String, var dpUrl:String)