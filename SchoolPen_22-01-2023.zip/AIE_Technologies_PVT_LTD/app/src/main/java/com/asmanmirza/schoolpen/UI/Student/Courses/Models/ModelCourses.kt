package com.asmanmirza.schoolpen.UI.Student.Courses.Models

class ModelCourses(var id:String, var title:String, var skills:String, var rating:String, var price:String, var bannerUrl:String)