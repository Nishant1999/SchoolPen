package com.asmanmirza.schoolpen.Models

class ModelEvents(var date:Int, var month:Int, var title:String, var duration:String, var priority:String, var type:String)