package com.asmanmirza.schoolpen.UI.Student.Classwork.Models

class ModelTest(var id:String, var title:String, var subject:String, var date:String, var marks:String, var duration:String,var imageID:Int, var upcoming:Boolean)