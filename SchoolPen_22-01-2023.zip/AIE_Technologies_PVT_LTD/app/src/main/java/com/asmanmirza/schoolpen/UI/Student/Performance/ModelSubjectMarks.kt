package com.asmanmirza.schoolpen.UI.Student.Performance

class ModelSubjectMarks(var id:String, var subject:String, var UT1:String, var MT:String, var UT2:String, var FT:String)