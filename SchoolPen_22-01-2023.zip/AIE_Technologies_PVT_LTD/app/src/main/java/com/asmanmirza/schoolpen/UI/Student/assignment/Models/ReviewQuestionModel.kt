package com.asmanmirza.schoolpen.UI.Student.assignment.Models

data class ReviewQuestionModel(val title: String, val type: String)
