package com.asmanmirza.schoolpen.Models

class ModelTeacherChat(var id:String, var name:String, var title:String, var lastMessage:String, var unreadCount:Int, var date:String, var dp:String, var isTeacher:Boolean)