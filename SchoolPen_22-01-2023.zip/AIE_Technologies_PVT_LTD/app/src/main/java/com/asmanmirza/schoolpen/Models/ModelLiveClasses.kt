package com.asmanmirza.schoolpen.Models

class ModelLiveClasses(var id:String, var title:String, var teacher:String, var stream:String, var totalJoinedStudents:String, var teacherDp:String)