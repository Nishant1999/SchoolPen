package com.asmanmirza.schoolpen.Models

class ModelDates(var date:Int, var fullDate:String, var dim:Boolean) {
}