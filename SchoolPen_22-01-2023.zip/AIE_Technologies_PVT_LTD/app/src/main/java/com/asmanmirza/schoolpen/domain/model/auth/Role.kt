package com.asmanmirza.schoolpen.domain.model.auth

data class Role(
    val authority: String
)