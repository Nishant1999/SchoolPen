package com.asmanmirza.schoolpen.presentation.main.Teacher.timetable

class ModelTimeTable(var id:String, var period:String, var className:String, var stream:String, var from:String, var to:String, val lunch:Boolean )